#ifndef YACC_HELPER_H
#define YACC_HELPER_H

#include "tree.h"
#include "memory.h"
#include "classtable.h"

/* Declared in the .y file; needed here for verifyFunctionSignature */
void yyerror(char *s);

/* ── Global declarations ─────────────────────────────────────── */
void handleGdecComplete(void);
void handleGidScalar(struct tnode *id, struct TypeInfo *typeData);
void handleGidArray1D(struct tnode *id, struct TypeInfo *typeData, int size);
void handleGidFunction(struct tnode *id, struct TypeInfo *typeData,
                       struct Paramstruct *params);

/* ── Function definitions ────────────────────────────────────── */
void handleParamInstall(struct Paramstruct *params);
void handleLidInstall(char *name, struct TypeInfo *typeData);

int verifyFunctionSignature(struct Gsymbol    *g,
                            struct TypeInfo   *retType,
                            struct Paramstruct *params);

void handleFdefPrint(char *funcName, struct tnode *body);
void handleFdefNoArgsPrint(char *funcName, struct tnode *body);
void handleMainPrint(struct tnode *body);

/* ── Class helpers ───────────────────────────────────────────── */
void handleMethodDec(ClassTableEntry    *cls,
                     const char         *methodName,
                     struct TypeInfo    *retType,
                     struct Paramstruct *params);

void handleClassComplete(ClassTableEntry *cls);

#endif /* YACC_HELPER_H */

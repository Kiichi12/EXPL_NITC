#include "classtable.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* ── Module-private state ────────────────────────────────────── */
ClassTableEntry *classTableHead = NULL;
static int nextClassId = 1;

/* ─────────────────────────────────────────────────────────────────
 * initClassTable
 * ───────────────────────────────────────────────────────────────── */
void initClassTable(void)
{
    classTableHead = NULL;
    nextClassId    = 1;
}

/* ─────────────────────────────────────────────────────────────────
 * lookupClass  —  O(n) linear scan, returns NULL if not found.
 * ───────────────────────────────────────────────────────────────── */
ClassTableEntry *lookupClass(const char *name)
{
    ClassTableEntry *c = classTableHead;
    while (c)
    {
        if (strcmp(c->name, name) == 0)
            return c;
        c = c->next;
    }
    return NULL;
}

/* ─────────────────────────────────────────────────────────────────
 * lookupMethod  —  O(m) scan over the class's method list.
 * ───────────────────────────────────────────────────────────────── */
MethodEntry *lookupMethod(ClassTableEntry *cls, const char *methodName)
{
    if (!cls) return NULL;
    MethodEntry *m = cls->methods;
    while (m)
    {
        if (strcmp(m->name, methodName) == 0)
            return m;
        m = m->next;
    }
    return NULL;
}

/* ─────────────────────────────────────────────────────────────────
 * findClassForMethod
 *   Scans all classes and returns the one that owns the named method.
 *   Called from the Fdef action to establish current_class_entry.
 * ───────────────────────────────────────────────────────────────── */
ClassTableEntry *findClassForMethod(const char *methodName)
{
    ClassTableEntry *c = classTableHead;
    while (c)
    {
        if (lookupMethod(c, methodName))
            return c;
        c = c->next;
    }
    return NULL;
}

/* ── Internal helper ─────────────────────────────────────────── */
static void appendClassEntry(ClassTableEntry *entry)
{
    if (!classTableHead)
    {
        classTableHead = entry;
        return;
    }
    ClassTableEntry *t = classTableHead;
    while (t->next) t = t->next;
    t->next = entry;
}

/* ─────────────────────────────────────────────────────────────────
 * installClass
 *   1. Checks for duplicate class names.
 *   2. Calls installType() to register the class name in the
 *      TypeTable so it can be used as a type in declarations.
 *   3. Creates and registers the ClassTableEntry.
 * ───────────────────────────────────────────────────────────────── */
ClassTableEntry *installClass(const char *name)
{
    if (lookupClass(name))
    {
        fprintf(stderr, "Error: Class '%s' already defined\n", name);
        exit(1);
    }

    TypeTableEntry *typeEntry = installType(name);

    ClassTableEntry *c = malloc(sizeof(ClassTableEntry));
    if (!c)
    {
        fprintf(stderr, "Error: Out of memory in installClass\n");
        exit(1);
    }
    c->name    = strdup(name);
    c->classId = nextClassId++;
    c->type    = typeEntry;
    c->methods = NULL;
    c->next    = NULL;

    appendClassEntry(c);
    return c;
}

/* ─────────────────────────────────────────────────────────────────
 * addMethod
 *   Registers a method in both the class table and the GST.
 *   Installing in the GST lets the existing Fdef grammar rule look
 *   the function up and verify/code-generate it without any
 *   special-casing for class methods.
 * ───────────────────────────────────────────────────────────────── */
MethodEntry *addMethod(ClassTableEntry  *cls,
                       const char       *methodName,
                       enum varType      retType,
                       TypeTableEntry   *retTypeEntry,
                       Paramstruct      *params)
{
    if (!cls)
    {
        fprintf(stderr, "Error: addMethod called with NULL class\n");
        exit(1);
    }

    if (lookupMethod(cls, methodName))
    {
        fprintf(stderr,
                "Error: Duplicate method '%s' in class '%s'\n",
                methodName, cls->name);
        exit(1);
    }

    /* Install in GST so Fdef can find and verify it */
    InstallFunction((char *)methodName, retType, retTypeEntry, params);

    /* Mirror the label assigned by InstallFunction */
    struct Gsymbol *g = Lookup((char *)methodName);
    int flabel = g ? g->flabel : -1;

    /* Build MethodEntry */
    MethodEntry *m = malloc(sizeof(MethodEntry));
    if (!m)
    {
        fprintf(stderr, "Error: Out of memory in addMethod\n");
        exit(1);
    }
    m->name         = strdup(methodName);
    m->retType      = retType;
    m->retTypeEntry = retTypeEntry;
    m->params       = params;
    m->flabel       = flabel;
    m->next         = NULL;

    /* Append to the class's method list */
    if (!cls->methods)
    {
        cls->methods = m;
    }
    else
    {
        MethodEntry *tail = cls->methods;
        while (tail->next) tail = tail->next;
        tail->next = m;
    }

    return m;
}

/* ─────────────────────────────────────────────────────────────────
 * printClassTable  —  debug dump
 * ───────────────────────────────────────────────────────────────── */
void printClassTable(void)
{
    printf("\n============== CLASS TABLE ==============\n");
    ClassTableEntry *c = classTableHead;
    if (!c)
    {
        printf("(empty)\n");
        printf("=========================================\n");
        return;
    }

    while (c)
    {
        printf("Class: %-12s  classId=%-3d  typeId=%d\n",
               c->name, c->classId,
               c->type ? c->type->typeId : -1);

        /* Fields */
        if (c->type && c->type->fields)
        {
            printf("  Fields (%d):\n", c->type->fieldCount);
            Fieldstruct *f = c->type->fields;
            while (f)
            {
                printf("    [offset %d] %-12s : %s  (PRIVATE)\n",
                       f->fieldOffset, f->name,
                       f->typeEntry ? f->typeEntry->name : "?");
                f = f->next;
            }
        }
        else
        {
            printf("  Fields: (none)\n");
        }

        /* Methods */
        if (c->methods)
        {
            printf("  Methods:  (PUBLIC)\n");
            MethodEntry *m = c->methods;
            while (m)
            {
                printf("    %-12s  retType=%-2d  label=F%d",
                       m->name, m->retType, m->flabel);
                if (m->retTypeEntry)
                    printf("  retTypeName=%s", m->retTypeEntry->name);
                if (m->params)
                {
                    printf("  params=(");
                    Paramstruct *p = m->params;
                    int first = 1;
                    while (p)
                    {
                        if (!first) printf(", ");
                        if (p->type == TYPE_USERDEF && p->typeEntry)
                            printf("%s:%s", p->name, p->typeEntry->name);
                        else
                            printf("%s:%d", p->name, p->type);
                        first = 0;
                        p = p->next;
                    }
                    printf(")");
                }
                else
                {
                    printf("  params=(none)");
                }
                printf("\n");
                m = m->next;
            }
        }
        else
        {
            printf("  Methods: (none)\n");
        }

        c = c->next;
        if (c) printf("  ---\n");
    }
    printf("=========================================\n");
}

#ifndef TREE_H
#define TREE_H

#include "constants.h"
#include "memory.h"
#include "typetable.h"
#include "classtable.h"     /* Stage 7: ClassTableEntry, MethodEntry */

/* ─────────────────────────────────────────────────────────────────
 * tnode  —  a single node in the Abstract Syntax Tree
 * ───────────────────────────────────────────────────────────────── */
typedef struct tnode
{
    union
    {
        int   val;      /* integer literal value      (NODE_NUM)    */
        char *strVal;   /* string literal value       (NODE_STRING) */
    };

    enum varType     type;          /* type of the expression               */
    TypeTableEntry  *typeEntry;     /* non-NULL for USERDEF / CLASS types   */
    struct Fieldstruct *fieldEntry; /* set for NODE_FIELD                   */

    char            *varname;       /* variable / function / method name    */

    enum nodeType    nodetype;
    struct Gsymbol  *Gentry;        /* GST entry for globals / functions    */

    struct tnode    *left, *right;  /* children                             */
} tnode;

/* ─────────────────────────────────────────────────────────────────
 * IR  —  pairs an AST with its owning function's GST entry
 * ───────────────────────────────────────────────────────────────── */
typedef struct IR
{
    struct tnode   *ast;
    struct Gsymbol *func;
} IR;

/* ─────────────────────────────────────────────────────────────────
 * TypeInfo  —  carries type info during parsing (used in %union)
 * ───────────────────────────────────────────────────────────────── */
struct TypeInfo
{
    enum varType    type;
    TypeTableEntry *typeEntry;
    int             ptrLevel;
};

/* ─────────────────────────────────────────────────────────────────
 * Semantic-checking context globals
 *   Defined in task1.y, read by tree.c for context-sensitive checks.
 *   current_function_name — name of the function/method being compiled.
 *   current_class_entry   — class being compiled (NULL outside classes).
 * ───────────────────────────────────────────────────────────────── */
extern char             *current_function_name;
extern ClassTableEntry  *current_class_entry;

/* =================================================================
 * Node-constructor declarations
 * ================================================================= */

/* ── Literal nodes ──────────────────────────────────────────────── */
struct tnode *makeNumNode(int val);
struct tnode *makeStringConstNode(char *lexeme);
struct tnode *makeNullNode(void);

/* ── Variable / l-value nodes ──────────────────────────────────── */
struct tnode *makeNewVarNode(char *name);
struct tnode *makeVarNode(char *name);
struct tnode *makeArrayNode(tnode *id, tnode *expr);

/* ── Pointer nodes ──────────────────────────────────────────────── */
struct tnode *makePointerNode(tnode *expr);
struct tnode *makeDerefNode(tnode *expr);

/* ── Arithmetic / boolean ───────────────────────────────────────── */
struct tnode *makeArithNode(int nodetype, struct tnode *l, struct tnode *r);
struct tnode *makeBoolNode(int nodetype, struct tnode *l, struct tnode *r);
struct tnode *makeNotNode(struct tnode *expr);

/* ── Assignment ─────────────────────────────────────────────────── */
struct tnode *makeAssignNode(struct tnode *id, struct tnode *expr);
struct tnode *makeArrayAssignNode(tnode *arrayNode, tnode *valExpr);

/* ── I/O ────────────────────────────────────────────────────────── */
struct tnode *makeReadNode(struct tnode *id);
struct tnode *makeWriteNode(struct tnode *expr);

/* ── Control flow ───────────────────────────────────────────────── */
struct tnode *makeConnectorNode(struct tnode *l, struct tnode *r);
struct tnode *makeWhileNode(struct tnode *condition, struct tnode *body);
struct tnode *makeBreakNode(void);
struct tnode *makeContinueNode(void);
struct tnode *makeDoWhileNode(struct tnode *body, struct tnode *condition);
struct tnode *makeRepeatUntilNode(struct tnode *body, struct tnode *condition);
struct tnode *makeIfElseNode(struct tnode *condition,
                             struct tnode *ifBody,
                             struct tnode *elseBody);
struct tnode *makeIfNode(struct tnode *condition, struct tnode *ifBody);

/* ── Function calls ─────────────────────────────────────────────── */
struct tnode *makeFuncallNode(char *funcname, struct tnode *arglist);
struct tnode *makeReturnNode(struct tnode *E, char *funcName);

/* ── Struct field access ────────────────────────────────────────── */
/*
 * makeFieldNode(base, fieldName)
 *   Looks up fieldName in base->typeEntry.
 *   SEMANTIC CHECK (Stage 7): if the base type is a class type,
 *   fields are PRIVATE — access is only allowed from within a method
 *   of that exact class (current_class_entry == the owning class).
 *   Attempting access from outside will exit with an error.
 */
struct tnode *makeFieldNode(struct tnode *base, char *fieldName);

/* ── Heap memory management ─────────────────────────────────────── */
struct tnode *makeAllocNode(struct tnode *varNode);
struct tnode *makeFreeNode(struct tnode *varNode);
struct tnode *makeInitializeNode(void);

/* ── Stage 7: class-specific node constructors ──────────────────── */

/*
 * makeSelfNode()
 *   Creates a NODE_SELF node representing the current object inside a
 *   class method.
 *   SEMANTIC CHECK: errors if called outside a class method
 *   (current_class_entry == NULL).
 */
struct tnode *makeSelfNode(void);

/*
 * makeNewNode(className)
 *   Creates a NODE_NEW node for "new ClassName()".
 *   SEMANTIC CHECK: className must be a known class.
 *   The resulting node has type=TYPE_CLASS and typeEntry pointing to
 *   the class's TypeTableEntry, matching the l-value it is assigned to.
 */
struct tnode *makeNewNode(const char *className);

/*
 * makeMethodCallNode(obj, methodName, arglist)
 *   Creates a NODE_METHOD_CALL node for "obj.method(args)".
 *   SEMANTIC CHECKS:
 *     - obj must have a class type (typeEntry maps to a ClassTableEntry).
 *     - methodName must be declared in that class (methods are PUBLIC).
 *     - Argument types / count must match the method's parameter list.
 */
struct tnode *makeMethodCallNode(struct tnode *obj,
                                 const char   *methodName,
                                 struct tnode *arglist);

/* ── Utilities ──────────────────────────────────────────────────── */
const char   *nodeTypeToString(int nodetype);
void          printAST(struct tnode *t, int level);
void          deleteTree(tnode *root);

#endif /* TREE_H */

#include "yacc-helper.h"
#include "classtable.h"
#include "memory.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern struct Gsymbol *Ghead;

/* ════════════════════════════════════════════════════════════════
 * Global-declaration handlers
 * ════════════════════════════════════════════════════════════════ */

void handleGdecComplete(void)
{
    printf("\n--- Global Declarations Complete ---\n");
    printSymbolTable();
}

void handleGidScalar(struct tnode *id, struct TypeInfo *typeData)
{
    if (typeData->type == TYPE_USERDEF || typeData->type == TYPE_CLASS)
    {
        InstallUdefType(id->varname, typeData->typeEntry);
    }
    else if (typeData->ptrLevel > 0)
    {
        InstallPointer(id->varname, typeData->type, typeData->ptrLevel);
    }
    else
    {
        Install(id->varname, typeData->type, 1);
    }
}

void handleGidArray1D(struct tnode *id, struct TypeInfo *typeData, int size)
{
    if (typeData->type == TYPE_USERDEF || typeData->type == TYPE_CLASS)
    {
        Install1DArray(id->varname, TYPE_USERDEF, size);
        struct Gsymbol *e = Lookup(id->varname);
        e->typeEntry = typeData->typeEntry;
    }
    else
    {
        Install1DArray(id->varname, typeData->type, size);
    }
}

void handleGidFunction(struct tnode *id, struct TypeInfo *typeData,
                       struct Paramstruct *params)
{
    InstallFunction(id->varname, typeData->type, typeData->typeEntry, params);
}

/* ════════════════════════════════════════════════════════════════
 * Local-declaration / parameter handlers
 * ════════════════════════════════════════════════════════════════ */

void handleParamInstall(struct Paramstruct *params)
{
    InstallParamsToLST(params);
}

void handleLidInstall(char *name, struct TypeInfo *typeData)
{
    LInstall(name, typeData->type, typeData->typeEntry, typeData->ptrLevel);
}

/* ════════════════════════════════════════════════════════════════
 * Function-definition helpers
 * ════════════════════════════════════════════════════════════════ */

int verifyFunctionSignature(struct Gsymbol    *g,
                            struct TypeInfo   *retType,
                            struct Paramstruct *params)
{
    if (!g)
    {
        yyerror("Function not declared");
        exit(1);
    }
    if (retType->type == TYPE_USERDEF || retType->type == TYPE_CLASS)
    {
        if (g->typeEntry != retType->typeEntry)
        {
            yyerror("Function definition return type does not match "
                    "declaration (class/struct type mismatch)");
            exit(1);
        }
    }
    if (g->type != retType->type || !CompareParamLists(g->paramlist, params))
    {
        yyerror("Function definition does not match its declaration");
        exit(1);
    }
    return 1;
}

void handleFdefPrint(char *funcName, struct tnode *body)
{
    printf("\n========================================\n");
    printf("FUNCTION: %s\n", funcName);
    printLST();
    printf("AST for function %s:\n", funcName);
    printAST(body, 0);
    printf("========================================\n");
}

void handleFdefNoArgsPrint(char *funcName, struct tnode *body)
{
    printf("\n========================================\n");
    printf("FUNCTION: %s (No Args)\n", funcName);
    printLST();
    printf("AST for function %s:\n", funcName);
    printAST(body, 0);
    printf("========================================\n");
}

void handleMainPrint(struct tnode *body)
{
    printf("\n========================================\n");
    printf("FUNCTION: main\n");
    printLST();
    printf("AST for main:\n");
    printAST(body, 0);
    printf("========================================\n");
}

/* ════════════════════════════════════════════════════════════════
 * Class helpers
 * ════════════════════════════════════════════════════════════════ */

void handleMethodDec(ClassTableEntry    *cls,
                     const char         *methodName,
                     struct TypeInfo    *retType,
                     struct Paramstruct *params)
{
    if (!cls)
    {
        fprintf(stderr,
                "Internal error: handleMethodDec called with NULL class\n");
        exit(1);
    }
    addMethod(cls, methodName, retType->type, retType->typeEntry, params);
}

void handleClassComplete(ClassTableEntry *cls)
{
    if (cls)
    {
        printf("\n--- Class '%s' definition complete ---\n", cls->name);
        printClassTable();
    }
}

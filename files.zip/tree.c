#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"
#include "classtable.h"
#include "constants.h"

/* ─────────────────────────────────────────────────────────────────
 * Semantic-context globals (defined in task1.y, extern-ed in tree.h)
 * ───────────────────────────────────────────────────────────────── */
/* extern char            *current_function_name; — from tree.h  */
/* extern ClassTableEntry *current_class_entry;   — from tree.h  */

/* ─────────────────────────────────────────────────────────────────
 * Internal helper: argument / parameter type checker.
 * Walks arglist (which may be a NODE_CONNECTOR tree) in parallel
 * with *param and verifies each argument's type matches the parameter.
 * On success advances *param past all matched params and returns 1.
 * On failure prints an error and returns 0.
 * ───────────────────────────────────────────────────────────────── */
static int compArgParam(struct Paramstruct **param, struct tnode *arg)
{
    if (arg == NULL)
        return 1;

    if (arg->nodetype == NODE_CONNECTOR)
    {
        if (!compArgParam(param, arg->left))
            return 0;
        return compArgParam(param, arg->right);
    }

    if (*param == NULL)
    {
        fprintf(stderr,
                "Semantic error: too many arguments (near '%s')\n",
                arg->varname ? arg->varname : "?");
        return 0;
    }

    /* Type check */
    if ((*param)->type == TYPE_USERDEF || (*param)->type == TYPE_CLASS)
    {
        if (arg->typeEntry != (*param)->typeEntry)
        {
            fprintf(stderr,
                    "Semantic error: argument type mismatch "
                    "(expected %s, got %s)\n",
                    (*param)->typeEntry ? (*param)->typeEntry->name : "?",
                    arg->typeEntry      ? arg->typeEntry->name      : "?");
            return 0;
        }
    }
    else if (arg->type != (*param)->type)
    {
        fprintf(stderr,
                "Semantic error: argument type mismatch "
                "(expected %d, got %d)\n",
                (*param)->type, arg->type);
        return 0;
    }

    /* Pointer-level check */
    int argPtr = 0;
    if (arg->Gentry)
        argPtr = arg->Gentry->ptrLevel;
    if (arg->nodetype == NODE_POINTER)
        argPtr++;

    if (argPtr != (*param)->ptrLevel)
    {
        fprintf(stderr,
                "Semantic error: pointer-level mismatch in argument\n");
        return 0;
    }

    *param = (*param)->next;
    return 1;
}

/*
 * checkArgList  —  wrapper that handles the no-arg sentinel correctly.
 *
 * InstallFunction stores a sentinel Paramstruct {type=TYPE_NULL} when
 * the function/method takes no parameters.  This helper skips the
 * sentinel for no-arg calls so compArgParam is never invoked on it.
 *
 * Returns 1 on success, 0 on failure.
 */
static int checkArgList(struct Gsymbol *g, struct tnode *arglist,
                        const char *callSite)
{
    struct Paramstruct *p = g->paramlist;

    /* Detect the no-param sentinel: single entry with type TYPE_NULL */
    int noParamSentinel = (p && p->type == TYPE_NULL && p->next == NULL);

    if (noParamSentinel)
    {
        if (arglist != NULL)
        {
            fprintf(stderr,
                    "Semantic error: '%s' takes no arguments but "
                    "arguments were provided\n", callSite);
            return 0;
        }
        return 1;   /* no args, no params — OK */
    }

    /* Normal path: walk args and params together */
    if (!compArgParam(&p, arglist) || p != NULL)
    {
        fprintf(stderr,
                "Semantic error: argument mismatch in call to '%s'\n",
                callSite);
        return 0;
    }
    return 1;
}

/* =================================================================
 * Literal node constructors
 * ================================================================= */

struct tnode *makeNumNode(int val)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->val      = val;
    t->type     = TYPE_INT;
    t->varname  = NULL;
    t->nodetype = NODE_NUM;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->left = t->right = NULL;
    return t;
}

struct tnode *makeStringConstNode(char *lexeme)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->strVal   = strdup(lexeme);
    t->type     = TYPE_STRING;
    t->varname  = NULL;
    t->nodetype = NODE_STRING;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->left = t->right = NULL;
    return t;
}

struct tnode *makeNullNode(void)
{
    tnode *t = malloc(sizeof(tnode));
    t->val      = 0;
    t->type     = TYPE_NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->varname    = NULL;
    t->nodetype   = NODE_NULL;
    t->Gentry     = NULL;
    t->left = t->right = NULL;
    return t;
}

/* =================================================================
 * Variable / l-value node constructors
 * ================================================================= */

struct tnode *makeNewVarNode(char *name)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->val      = 0;
    t->varname  = strdup(name);
    t->nodetype = NODE_ID;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->left = t->right = NULL;
    return t;
}

struct tnode *makeVarNode(char *name)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->varname  = strdup(name);
    t->nodetype = NODE_ID;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->left = t->right = NULL;

    /* Search Local Symbol Table first */
    struct Lsymbol *l = LLookup(name);
    if (l)
    {
        t->type      = l->type;
        t->Gentry    = NULL;
        t->typeEntry = l->typeEntry;
        return t;
    }

    /* Then search Global Symbol Table */
    struct Gsymbol *g = Lookup(name);
    if (g)
    {
        t->type      = g->type;
        t->Gentry    = g;
        t->typeEntry = g->typeEntry;
        return t;
    }

    fprintf(stderr, "Semantic error: variable '%s' undeclared\n", name);
    exit(1);
}

struct tnode *makeArrayNode(tnode *id, tnode *expr)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->val     = expr->val;
    t->varname = strdup(id->varname);
    t->nodetype = NODE_ARRAY_ELEMENT;
    t->left  = id;
    t->right = expr;
    t->fieldEntry = NULL;

    struct Gsymbol *g = Lookup(id->varname);
    if (!g)
    {
        fprintf(stderr, "Semantic error: undeclared array '%s'\n",
                id->varname);
        exit(1);
    }
    t->Gentry    = g;
    t->type      = g->type;
    t->typeEntry = g->typeEntry;

    if (expr->val >= g->size)
    {
        fprintf(stderr, "Semantic error: array index out of bounds for '%s' "
                        "(index %d, size %d)\n",
                id->varname, expr->val, g->size);
        exit(1);
    }
    return t;
}

/* =================================================================
 * Pointer node constructors
 * ================================================================= */

struct tnode *makePointerNode(tnode *var)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_POINTER;
    t->left       = var;
    t->right      = NULL;
    t->varname    = strdup(var->varname);
    t->type       = var->type;
    t->typeEntry  = var->typeEntry;
    t->Gentry     = var->Gentry;
    t->fieldEntry = NULL;
    return t;
}

struct tnode *makeDerefNode(tnode *id)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_DEREF;
    t->left       = id;
    t->right      = NULL;
    t->varname    = strdup(id->varname);
    t->Gentry     = NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    return t;
}

/* =================================================================
 * Arithmetic / boolean node constructors
 * ================================================================= */

struct tnode *makeArithNode(int nodetype, struct tnode *l, struct tnode *r)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->type       = TYPE_INT;
    t->nodetype   = nodetype;
    t->left       = l;
    t->right      = r;
    t->varname    = NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

struct tnode *makeBoolNode(int nodetype, struct tnode *l, struct tnode *r)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->type       = TYPE_BOOL;
    t->nodetype   = nodetype;
    t->left       = l;
    t->right      = r;
    t->varname    = NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

struct tnode *makeNotNode(struct tnode *expr)
{
    tnode *t = malloc(sizeof(struct tnode));
    t->type       = TYPE_BOOL;
    t->nodetype   = NODE_NOT;
    t->left       = expr;
    t->right      = NULL;
    t->varname    = NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

/* =================================================================
 * Assignment node constructors
 * ================================================================= */

struct tnode *makeAssignNode(struct tnode *lval, struct tnode *expr)
{
    /* ── Type compatibility check ─────────────────────────────── */
    if (expr->type != TYPE_NULL)
    {
        if (lval->type == TYPE_USERDEF || lval->type == TYPE_CLASS ||
            expr->type == TYPE_USERDEF || expr->type == TYPE_CLASS)
        {
            if (lval->typeEntry != expr->typeEntry)
            {
                fprintf(stderr,
                        "Semantic error (makeAssignNode): type mismatch — "
                        "cannot assign '%s' to '%s'\n",
                        expr->typeEntry  ? expr->typeEntry->name  : "?",
                        lval->typeEntry  ? lval->typeEntry->name  : "?");
                exit(1);
            }
        }
        else if (lval->type != expr->type)
        {
            fprintf(stderr,
                    "Semantic error (makeAssignNode): type mismatch "
                    "(lval type=%d, expr type=%d)\n",
                    lval->type, expr->type);
            exit(1);
        }
    }

    struct tnode *t = malloc(sizeof(struct tnode));
    t->val        = 0;
    t->type       = TYPE_NULL;
    t->varname    = lval->varname ? strdup(lval->varname) : NULL;
    t->nodetype   = NODE_ASSIGN;
    t->left       = lval;
    t->right      = expr;
    t->Gentry     = lval->Gentry;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    return t;
}

struct tnode *makeArrayAssignNode(tnode *arrayNode, tnode *valExpr)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    struct Gsymbol *g = Lookup(arrayNode->varname);
    if (!g)
    {
        fprintf(stderr, "Semantic error: undeclared array '%s'\n",
                arrayNode->varname);
        exit(1);
    }
    if (g->type != valExpr->type)
    {
        fprintf(stderr,
                "Semantic error: type mismatch in array assignment to '%s'\n",
                arrayNode->varname);
        exit(1);
    }
    t->varname    = strdup(arrayNode->varname);
    t->nodetype   = NODE_ARRAY_ASSIGN;
    t->type       = TYPE_NULL;
    t->left       = arrayNode;
    t->right      = valExpr;
    t->Gentry     = g;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    return t;
}

/* =================================================================
 * I/O node constructors
 * ================================================================= */

struct tnode *makeReadNode(struct tnode *id)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->val        = 0;
    t->type       = TYPE_NULL;
    t->varname    = id->varname ? strdup(id->varname) : NULL;
    t->nodetype   = NODE_READ;
    t->left       = id;
    t->right      = NULL;
    t->Gentry     = id->Gentry;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    return t;
}

struct tnode *makeWriteNode(struct tnode *expr)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->val        = 0;
    t->type       = TYPE_NULL;
    t->varname    = NULL;
    t->nodetype   = NODE_WRITE;
    t->left       = expr;
    t->right      = NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

/* =================================================================
 * Control-flow node constructors
 * ================================================================= */

struct tnode *makeConnectorNode(struct tnode *l, struct tnode *r)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->varname    = NULL;
    t->nodetype   = NODE_CONNECTOR;
    t->left       = l;
    t->right      = r;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

struct tnode *makeWhileNode(struct tnode *condition, struct tnode *body)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_WHILE;
    t->left       = condition;
    t->right      = body;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->varname    = NULL;
    return t;
}

struct tnode *makeBreakNode(void)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_BREAK;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->varname    = NULL;
    t->left = t->right = NULL;
    return t;
}

struct tnode *makeContinueNode(void)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_CONTINUE;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->varname    = NULL;
    t->left = t->right = NULL;
    return t;
}

struct tnode *makeDoWhileNode(struct tnode *body, struct tnode *condition)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_DOWHILE;
    t->left       = body;
    t->right      = condition;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->varname    = NULL;
    return t;
}

struct tnode *makeRepeatUntilNode(struct tnode *body, struct tnode *condition)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_REPEAT;
    t->left       = body;
    t->right      = condition;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->varname    = NULL;
    return t;
}

struct tnode *makeIfElseNode(struct tnode *condition,
                             struct tnode *ifBody,
                             struct tnode *elseBody)
{
    struct tnode *tifelse = malloc(sizeof(struct tnode));
    tifelse->nodetype   = NODE_CONNECTOR;
    tifelse->left       = ifBody;
    tifelse->right      = elseBody;
    tifelse->type       = TYPE_NULL;
    tifelse->typeEntry  = NULL;
    tifelse->fieldEntry = NULL;
    tifelse->Gentry     = NULL;
    tifelse->varname    = NULL;

    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_IFELSE;
    t->left       = condition;
    t->right      = tifelse;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->varname    = NULL;
    return t;
}

struct tnode *makeIfNode(struct tnode *condition, struct tnode *ifBody)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_IF;
    t->left       = condition;
    t->right      = ifBody;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    t->varname    = NULL;
    return t;
}

/* =================================================================
 * Function-call / return node constructors
 * ================================================================= */

struct tnode *makeFuncallNode(char *funcname, struct tnode *arglist)
{
    struct Gsymbol *g = Lookup(funcname);
    if (!g)
    {
        fprintf(stderr,
                "Semantic error: function '%s' undeclared\n", funcname);
        exit(1);
    }

    if (!checkArgList(g, arglist, funcname))
        exit(1);

    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_FUNCALL;
    t->varname    = strdup(funcname);
    t->left       = arglist;
    t->right      = NULL;
    t->Gentry     = g;
    t->type       = g->type;
    t->typeEntry  = g->typeEntry;
    t->fieldEntry = NULL;
    return t;
}

struct tnode *makeReturnNode(struct tnode *E, char *funcName)
{
    struct tnode *t = malloc(sizeof(struct tnode));
    t->nodetype   = NODE_RET;
    t->left       = E;
    t->right      = NULL;
    t->varname    = strdup(funcName);
    t->fieldEntry = NULL;
    t->Gentry     = NULL;

    if (E)
    {
        t->type      = E->type;
        t->typeEntry = E->typeEntry;
    }
    else
    {
        t->type      = TYPE_NULL;
        t->typeEntry = NULL;
    }
    return t;
}

/* =================================================================
 * Struct field-access node constructor
 *
 * SEMANTIC CHECK (Stage 7 — class field privacy):
 *   If base->typeEntry resolves to a class in the class table, then
 *   the field is PRIVATE.  Access is only permitted when:
 *     1. We are currently compiling a method (current_class_entry != NULL)
 *     2. AND that method belongs to the exact class that owns the field.
 *   Any other access raises a compile-time error.
 * ================================================================= */
struct tnode *makeFieldNode(struct tnode *base, char *fieldName)
{
    TypeTableEntry *baseType = base->typeEntry;

    if (!baseType)
    {
        fprintf(stderr,
                "Semantic error: base of '.' operator is not a "
                "structured / class type\n");
        exit(1);
    }

    /* ── Privacy enforcement for class fields ──────────────────── */
    ClassTableEntry *cls = lookupClass(baseType->name);
    if (cls)
    {
        /*
         * The base expression has a class type: apply privacy rules.
         *
         * Rule: fields of a class are PRIVATE.
         * They may only be accessed from within a method of that
         * exact class (current_class_entry must equal cls).
         */
        if (current_class_entry == NULL)
        {
            fprintf(stderr,
                    "Semantic error: field '%s' of class '%s' is private — "
                    "cannot be accessed outside a class method\n",
                    fieldName, cls->name);
            exit(1);
        }
        if (current_class_entry != cls)
        {
            fprintf(stderr,
                    "Semantic error: field '%s' of class '%s' is private — "
                    "cannot be accessed from a method of class '%s'\n",
                    fieldName, cls->name, current_class_entry->name);
            exit(1);
        }
        /* Inside the correct class method — permitted. */
    }
    /* For struct types (not in class table) no privacy restriction. */

    /* ── Field existence check ─────────────────────────────────── */
    Fieldstruct *field = lookupField(baseType, fieldName);
    if (!field)
    {
        fprintf(stderr,
                "Semantic error: field '%s' does not exist in type '%s'\n",
                fieldName, baseType->name);
        exit(1);
    }

    /* ── Build the node ────────────────────────────────────────── */
    tnode *t = malloc(sizeof(tnode));
    t->nodetype   = NODE_FIELD;
    t->type       = field->typeEntry->typeId;
    t->left       = base;
    t->right      = NULL;
    t->varname    = strdup(fieldName);
    t->typeEntry  = field->typeEntry;
    t->fieldEntry = field;
    t->Gentry     = NULL;
    return t;
}

/* =================================================================
 * Heap memory management node constructors
 * ================================================================= */

struct tnode *makeAllocNode(struct tnode *varNode)
{
    tnode *t = malloc(sizeof(tnode));
    t->nodetype   = NODE_ALLOC;
    t->left       = varNode;
    t->type       = TYPE_USERDEF;
    t->typeEntry  = varNode->typeEntry;
    t->right      = NULL;
    t->varname    = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

struct tnode *makeFreeNode(struct tnode *varNode)
{
    tnode *t = malloc(sizeof(tnode));
    t->nodetype   = NODE_FREE;
    t->left       = varNode;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->right      = NULL;
    t->varname    = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

struct tnode *makeInitializeNode(void)
{
    tnode *t = malloc(sizeof(tnode));
    t->nodetype   = NODE_INITIALIZE;
    t->type       = TYPE_NULL;
    t->typeEntry  = NULL;
    t->left = t->right = NULL;
    t->varname    = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

/* =================================================================
 * Stage 7 — Class-specific node constructors
 * ================================================================= */

/* ── makeSelfNode ──────────────────────────────────────────────────
 *
 * Creates a NODE_SELF node representing the implicit current-object
 * reference inside a class method.
 *
 * SEMANTIC CHECK:
 *   'self' is only meaningful inside a class method body.
 *   current_class_entry is set by the Fdef rule (via findClassForMethod)
 *   exactly when we are compiling a class method; it is NULL otherwise.
 * ─────────────────────────────────────────────────────────────────── */
struct tnode *makeSelfNode(void)
{
    if (current_class_entry == NULL)
    {
        fprintf(stderr,
                "Semantic error: 'self' used outside a class method\n");
        exit(1);
    }

    tnode *t = malloc(sizeof(tnode));
    t->nodetype   = NODE_SELF;
    t->type       = TYPE_CLASS;
    t->typeEntry  = current_class_entry->type;   /* class's TypeTableEntry */
    t->varname    = strdup("self");
    t->left = t->right = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

/* ── makeNewNode ───────────────────────────────────────────────────
 *
 * Creates a NODE_NEW node for the expression  new ClassName().
 * The node's type is set to TYPE_CLASS with the class's TypeTableEntry
 * so that the assignment LValue ASSIGN NEW_KW ID LPAREN RPAREN passes
 * the type-compatibility check in makeAssignNode.
 *
 * SEMANTIC CHECK:
 *   The class name must exist in the class table.
 * ─────────────────────────────────────────────────────────────────── */
struct tnode *makeNewNode(const char *className)
{
    ClassTableEntry *cls = lookupClass(className);
    if (!cls)
    {
        fprintf(stderr,
                "Semantic error: 'new %s()' — '%s' is not a known class\n",
                className, className);
        exit(1);
    }

    tnode *t = malloc(sizeof(tnode));
    t->nodetype   = NODE_NEW;
    t->type       = TYPE_CLASS;
    t->typeEntry  = cls->type;
    t->varname    = strdup(className);
    t->left = t->right = NULL;
    t->fieldEntry = NULL;
    t->Gentry     = NULL;
    return t;
}

/* ── makeMethodCallNode ────────────────────────────────────────────
 *
 * Creates a NODE_METHOD_CALL node for  obj.method(args)  or
 * self.method(args).
 *
 * Node layout:
 *   left  → obj (the receiver expression — NODE_ID or NODE_SELF)
 *   right → arglist (may be NULL for no-arg calls)
 *   varname → method name
 *   Gentry  → GST entry for the method (for code generation)
 *
 * SEMANTIC CHECKS:
 *   1. obj must carry a class type (typeEntry maps to a ClassTableEntry).
 *   2. methodName must be declared in that class  (methods are PUBLIC —
 *      no access restriction here).
 *   3. Argument types/count must match the method's parameter list.
 * ─────────────────────────────────────────────────────────────────── */
struct tnode *makeMethodCallNode(struct tnode *obj,
                                 const char   *methodName,
                                 struct tnode *arglist)
{
    /* ── Check 1: receiver must have a class type ─────────────── */
    if (!obj->typeEntry)
    {
        fprintf(stderr,
                "Semantic error: receiver of '.%s()' has no type information — "
                "not a class object\n", methodName);
        exit(1);
    }

    ClassTableEntry *cls = lookupClass(obj->typeEntry->name);
    if (!cls)
    {
        fprintf(stderr,
                "Semantic error: receiver type '%s' is not a class — "
                "cannot call method '%s'\n",
                obj->typeEntry->name, methodName);
        exit(1);
    }

    /* ── Check 2: method must be declared in the class ───────── */
    MethodEntry *method = lookupMethod(cls, methodName);
    if (!method)
    {
        fprintf(stderr,
                "Semantic error: class '%s' has no method named '%s'\n",
                cls->name, methodName);
        exit(1);
    }

    /* ── Check 3: argument type / count match ────────────────── */
    struct Gsymbol *g = Lookup((char *)methodName);
    if (!g)
    {
        /* Should not happen if addMethod did its job */
        fprintf(stderr,
                "Internal error: method '%s' not found in GST\n", methodName);
        exit(1);
    }

    if (!checkArgList(g, arglist, methodName))
        exit(1);

    /* ── Build the node ──────────────────────────────────────── */
    tnode *t = malloc(sizeof(tnode));
    t->nodetype   = NODE_METHOD_CALL;
    t->varname    = strdup(methodName);
    t->left       = obj;       /* receiver                          */
    t->right      = arglist;   /* argument list (may be NULL)       */
    t->Gentry     = g;
    t->type       = g->type;
    t->typeEntry  = g->typeEntry;
    t->fieldEntry = NULL;
    return t;
}

/* =================================================================
 * Debug utilities
 * ================================================================= */

const char *nodeTypeToString(int nodetype)
{
    switch (nodetype)
    {
        case NODE_NUM:          return "NUM";
        case NODE_STRING:       return "STRING";
        case NODE_NULL:         return "NULL";

        case NODE_ID:           return "ID";
        case NODE_ARRAY_ELEMENT: return "ARRAY_ELEMENT";
        case NODE_FIELD:        return "FIELD";

        case NODE_POINTER:      return "POINTER";
        case NODE_DEREF:        return "DEREFERENCE";

        case NODE_FUNCALL:      return "FUNCALL";
        case NODE_METHOD_CALL:  return "METHOD_CALL";
        case NODE_RET:          return "RETURN";

        case NODE_PLUS:         return "PLUS";
        case NODE_MINUS:        return "MINUS";
        case NODE_MUL:          return "MUL";
        case NODE_DIV:          return "DIV";

        case NODE_ASSIGN:       return "ASSIGN";
        case NODE_ARRAY_ASSIGN: return "ARRAY_ASSIGN";

        case NODE_READ:         return "READ";
        case NODE_WRITE:        return "WRITE";

        case NODE_CONNECTOR:    return "CONNECTOR";

        case NODE_WHILE:        return "WHILE";
        case NODE_DOWHILE:      return "DOWHILE";
        case NODE_REPEAT:       return "REPEAT_UNTIL";
        case NODE_IF:           return "IF";
        case NODE_IFELSE:       return "IFELSE";
        case NODE_BREAK:        return "BREAK";
        case NODE_CONTINUE:     return "CONTINUE";

        case NODE_LT:           return "LT";
        case NODE_LE:           return "LE";
        case NODE_GT:           return "GT";
        case NODE_GE:           return "GE";
        case NODE_EQ:           return "EQ";
        case NODE_NE:           return "NE";
        case NODE_AND:          return "AND";
        case NODE_OR:           return "OR";
        case NODE_NOT:          return "NOT";

        case NODE_ALLOC:        return "ALLOC";
        case NODE_FREE:         return "FREE";
        case NODE_INITIALIZE:   return "INITIALIZE";

        case NODE_NEW:          return "NEW";
        case NODE_DELETE:       return "DELETE";
        case NODE_SELF:         return "SELF";

        default:                return "UNKNOWN";
    }
}

void printAST(struct tnode *t, int level)
{
    if (!t) return;

    for (int i = 0; i < level; i++) printf("  ");
    printf("|- %s", nodeTypeToString(t->nodetype));

    switch (t->nodetype)
    {
        case NODE_NUM:
            printf(" (%d)", t->val);
            break;
        case NODE_STRING:
            printf(" (%s)", t->strVal);
            break;
        case NODE_ID:
        case NODE_ASSIGN:
        case NODE_READ:
        case NODE_FUNCALL:
            if (t->varname) printf(" (%s)", t->varname);
            break;
        case NODE_METHOD_CALL:
            printf(" (.%s)", t->varname ? t->varname : "?");
            break;
        case NODE_FIELD:
            if (t->varname)    printf(" (%s)", t->varname);
            if (t->fieldEntry) printf(" @offset=%d", t->fieldEntry->fieldOffset);
            break;
        case NODE_SELF:
            printf(" [class=%s]",
                   t->typeEntry ? t->typeEntry->name : "?");
            break;
        case NODE_NEW:
            printf(" (new %s)", t->varname ? t->varname : "?");
            break;
        default:
            break;
    }

    /* Annotate type for expressions (skip statement/connector nodes) */
    if (t->nodetype != NODE_CONNECTOR   &&
        t->nodetype != NODE_ASSIGN      &&
        t->nodetype != NODE_ARRAY_ASSIGN &&
        t->nodetype != NODE_READ        &&
        t->nodetype != NODE_WRITE       &&
        t->nodetype != NODE_WHILE       &&
        t->nodetype != NODE_IF          &&
        t->nodetype != NODE_IFELSE      &&
        t->nodetype != NODE_BREAK       &&
        t->nodetype != NODE_CONTINUE    &&
        t->nodetype != NODE_RET         &&
        t->nodetype != NODE_INITIALIZE)
    {
        if (t->typeEntry)
            printf("  [type=%s]", t->typeEntry->name);
    }

    printf("\n");

    printAST(t->left,  level + 1);
    printAST(t->right, level + 1);
}

void deleteTree(tnode *root)
{
    if (!root) return;
    deleteTree(root->left);
    deleteTree(root->right);
    free(root);
}

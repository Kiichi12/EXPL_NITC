%{
    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include "tree.h"
    #include "memory.h"
    #include "yacc-helper.h"
    #include "codegeneration.h"
    #include "register.h"
    #include "labels.h"
    #include "typetable.h"
    #include "classtable.h"

    void yyerror(char *s);
    int yylex();
    extern FILE  *yyin;
    extern int    lineNumber;
    tnode        *root;
    FILE         *interim_file;
    char         *current_function_name;
    extern char  *yytext;

    /* Type of the current declaration line (shared global) */
    struct TypeInfo currentTypeData;

    /* ── Parsing-time context (static = local to this translation unit) ── */

    /* Set while parsing TypeDef or ClassDef field lists */
    static TypeTableEntry  *currentUdefType   = NULL;

    /* Set while parsing a ClassDefBlock */
    static ClassTableEntry *currentClassEntry = NULL;

    /* ── Semantic-checking context (global — read by tree.c via extern) ── */

    /*
     * current_class_entry
     *   Non-NULL only while compiling the body of a class METHOD (inside Fdef).
     *   Set by the Fdef mid-rule action via findClassForMethod(); cleared at the
     *   end of Fdef.  tree.c reads this to enforce field privacy and validate
     *   'self' usage.
     */
    ClassTableEntry *current_class_entry = NULL;
%}

%union
{
    struct tnode       *node;
    struct Paramstruct *param;
    struct TypeInfo     typeData;
}

%token <node> NUM ID STRING SELF_KW
%token INT STR MAIN DECL ENDDECL kBEGIN kEND WRITE READ RETURN
       IF THEN ELSE ENDIF
       WHILE DO ENDWHILE BREAK CONTINUE
       SEMICOLON COMMA LPAREN RPAREN LBRACE RBRACE LSQBR RSQBR
       ASSIGN
       ADDRESS_OF MUL
       TYPE_KW ENDTYPE DOT
       ALLOC FREE_KW INITIALIZE NULLVAL
       CLASS ENDCLASS NEW_KW DELETE_KW

%type <node> E Stmt Slist InputStmt OutputStmt AssgStmt
             IfStmt WhileStmt ContinueStmt BreakStmt
             Body MainBlock ArgList LValue
             FreeStmt InitStmt FieldAccess DeleteStmt

%type <param> Param ParamList
%type <typeData> Type

%left  OR
%left  AND
%right NOT
%left  PLUS MINUS
%left  MUL DIV
%nonassoc LT LE GT GE EQ NE
%nonassoc UNARY

%%

/* ════════════════════════════════════════════════════════════════
 * Top-level program structure
 * ════════════════════════════════════════════════════════════════ */

Program:
  /* empty */
  | ClassDefBlock TypeDefBlock GDeclarations FdefBlock MainBlock { root = $5; }
  | ClassDefBlock TypeDefBlock GDeclarations MainBlock           { root = $4; }
  | ClassDefBlock TypeDefBlock FdefBlock MainBlock               { root = $4; }
  | ClassDefBlock GDeclarations FdefBlock MainBlock              { root = $4; }
  | ClassDefBlock GDeclarations MainBlock                        { root = $3; }
  | ClassDefBlock FdefBlock MainBlock                            { root = $3; }
  | TypeDefBlock GDeclarations FdefBlock MainBlock               { root = $4; }
  | TypeDefBlock GDeclarations MainBlock                         { root = $3; }
  | TypeDefBlock FdefBlock MainBlock                             { root = $3; }
  | GDeclarations FdefBlock MainBlock                            { root = $3; }
  | GDeclarations MainBlock                                      { root = $2; }
  | FdefBlock MainBlock                                          { root = $2; }
  ;

/* ════════════════════════════════════════════════════════════════
 * CLASS DEFINITION BLOCK
 *
 *  class ClassName {
 *      <field declarations>     ← FieldDecList  (mandatory)
 *      <method declarations>    ← MethodDecList (optional)
 *      <method definitions>     ← MethodDefList (optional)
 *  }
 *
 * Mid-rule action after "CLASS ID":
 *   •  installClass() creates the ClassTableEntry + TypeTableEntry.
 *   •  currentUdefType is set so the shared FieldDec rule populates
 *      the class's field list exactly as it does for structs.
 *   •  currentClassEntry is set for MethodDec actions.
 * ════════════════════════════════════════════════════════════════ */

ClassDefBlock:
  CLASS ID
  {
      currentClassEntry = installClass($2->varname);
      currentUdefType   = currentClassEntry->type;
  }
  LBRACE FieldDecList MethodDecList MethodDefList RBRACE
  {
      handleClassComplete(currentClassEntry);
      currentClassEntry = NULL;
      currentUdefType   = NULL;
  }
  | CLASS ID
  {
      currentClassEntry = installClass($2->varname);
      currentUdefType   = currentClassEntry->type;
  }
  LBRACE FieldDecList RBRACE
  {
      handleClassComplete(currentClassEntry);
      currentClassEntry = NULL;
      currentUdefType   = NULL;
  }
  ;

/* ── Method declarations (signatures, no body) ──────────────────
 *   handleMethodDec() calls addMethod() which in turn calls
 *   InstallFunction(), so the matching Fdef can find and verify
 *   the method in the GST without special-casing.
 * ─────────────────────────────────────────────────────────────── */

MethodDecList:
  MethodDecList MethodDec
  | MethodDec
  ;

MethodDec:
  Type ID LPAREN ParamList RPAREN
  {
      handleMethodDec(currentClassEntry, $2->varname, &$1, $4);
  }
  | Type ID LPAREN RPAREN
  {
      handleMethodDec(currentClassEntry, $2->varname, &$1, NULL);
  }
  ;

/* ── Method definitions (bodies, reuse Fdef entirely) ────────── */

MethodDefList:
  MethodDefList MethodDef
  | MethodDef
  ;

MethodDef:
  Fdef
  ;

/* ════════════════════════════════════════════════════════════════
 * TYPE (struct) DEFINITION BLOCK
 * ════════════════════════════════════════════════════════════════ */

TypeDefBlock:
  TYPE_KW TypeDefList ENDTYPE
  {
      printTypeTable();
  }
  ;

TypeDefList:
  TypeDefList TypeDef
  | TypeDef
  ;

TypeDef:
  ID
  {
      currentUdefType = installType($1->varname);
  }
  LBRACE FieldDecList RBRACE
  {
      currentUdefType = NULL;
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * FIELD DECLARATIONS
 *   Shared between TypeDef and ClassDefBlock.
 *   currentUdefType must be set by the enclosing rule before this
 *   list is reduced.
 * ════════════════════════════════════════════════════════════════ */

FieldDecList:
  FieldDecList FieldDec
  | FieldDec
  ;

FieldDec:
  Type ID SEMICOLON
  {
      TypeTableEntry *t = NULL;

      if ($1.type == TYPE_USERDEF || $1.type == TYPE_CLASS)
      {
          t = $1.typeEntry;
      }
      else
      {
          if ($1.type == TYPE_INT)    t = lookupType("int");
          if ($1.type == TYPE_STRING) t = lookupType("string");
          if ($1.type == TYPE_BOOL)   t = lookupType("bool");
      }

      if (!t)
      {
          yyerror("Unknown field type");
          exit(1);
      }
      if (currentUdefType->fieldCount >= MAX_FIELDS_IN_USER_TYPE)
      {
          yyerror("Maximum number of fields exceeded");
          exit(1);
      }

      addField(currentUdefType, $2->varname, t);
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * GLOBAL DECLARATIONS
 * ════════════════════════════════════════════════════════════════ */

GDeclarations:
    DECL GDecList ENDDECL { handleGdecComplete(); }
  | DECL ENDDECL
  | /* empty */
  ;

GDecList:
  GDecList GDecl
  | GDecl
  ;

GDecl:
  Type GidList SEMICOLON
  ;

GidList:
  GidList COMMA Gid
  | Gid
  ;

Gid:
  ID
  {
      handleGidScalar($1, &currentTypeData);
  }
  | ID LSQBR NUM RSQBR
  {
      handleGidArray1D($1, &currentTypeData, $3->val);
  }
  | ID LPAREN ParamList RPAREN
  {
      struct TypeInfo funcType = $<typeData>0;
      handleGidFunction($1, &funcType, $3);
  }
  | ID LPAREN RPAREN
  {
      handleGidFunction($1, &currentTypeData, NULL);
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * TYPE EXPRESSIONS
 *
 *   If an ID is not a known struct type, the class table is checked
 *   next — a class name is also a valid type.
 * ════════════════════════════════════════════════════════════════ */

Type:
  INT
  {
      $$.type = TYPE_INT; $$.ptrLevel = 0; $$.typeEntry = NULL;
      currentTypeData = $$;
  }
  | STR
  {
      $$.type = TYPE_STRING; $$.ptrLevel = 0; $$.typeEntry = NULL;
      currentTypeData = $$;
  }
  | MUL Type
  {
      $$ = $2; $$.ptrLevel++;
      currentTypeData = $$;
  }
  | ID
  {
      TypeTableEntry *t = lookupType($1->varname);
      if (!t || t->typeId <= TYPE_USERDEF)
      {
          /* Not a known struct — try class table */
          ClassTableEntry *c = lookupClass($1->varname);
          if (!c)
          {
              yyerror("Undefined type name");
              exit(1);
          }
          t = c->type;
          $$.type      = TYPE_CLASS;
          $$.typeEntry = t;
          $$.ptrLevel  = 0;
          currentTypeData = $$;
      }
      else
      {
          $$.type      = TYPE_USERDEF;
          $$.typeEntry = t;
          $$.ptrLevel  = 0;
          currentTypeData = $$;
      }
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * PARAMETER LISTS
 * ════════════════════════════════════════════════════════════════ */

ParamList:
  ParamList COMMA Param { $$ = AppendParam($1, $3); }
  | Param               { $$ = $1; }
  ;

Param:
  Type ID
  {
      $$ = CreateParam($2->varname, $1.type, $1.typeEntry, $1.ptrLevel);
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * FUNCTION DEFINITIONS  (also used for class method bodies)
 *
 * Stage 7 additions in the mid-rule action:
 *   After "Type ID LPAREN …" is seen, findClassForMethod() checks
 *   whether the function name is a method of any class.  If so,
 *   current_class_entry is set so that tree.c semantic checks work
 *   correctly throughout the body.  It is cleared at the end of Fdef.
 * ════════════════════════════════════════════════════════════════ */

FdefBlock:
  FdefBlock Fdef
  | Fdef
  ;

Fdef:
  Type ID LPAREN ParamList RPAREN
  {
      handleParamInstall($4);
      current_function_name = $2->varname;
      /* Stage 7: determine if this is a class method */
      current_class_entry   = findClassForMethod($2->varname);
  }
  LBRACE LdeclBlock Body RBRACE
  {
      struct TypeInfo retType = $1;
      verifyFunctionSignature(Lookup($2->varname), &retType, $4);
      handleFdefPrint($2->varname, $9);

      struct Gsymbol *g = Lookup($2->varname);
      codeGen($9, interim_file, g);

      current_function_name = NULL;
      current_class_entry   = NULL;   /* Stage 7: leave class context */
      resetLocalSymbolTable();
  }
  | Type ID LPAREN RPAREN
  {
      current_function_name = $2->varname;
      /* Stage 7: determine if this is a class method */
      current_class_entry   = findClassForMethod($2->varname);
  }
  LBRACE LdeclBlock Body RBRACE
  {
      struct TypeInfo retType = $1;
      verifyFunctionSignature(Lookup($2->varname), &retType, NULL);
      handleFdefNoArgsPrint($2->varname, $7);

      struct Gsymbol *g = Lookup($2->varname);
      codeGen($7, interim_file, g);

      current_function_name = NULL;
      current_class_entry   = NULL;   /* Stage 7: leave class context */
      resetLocalSymbolTable();
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * LOCAL DECLARATIONS
 * ════════════════════════════════════════════════════════════════ */

LdeclBlock:
  DECL LDecList ENDDECL
  | DECL ENDDECL
  | /* empty */
  ;

LDecList:
  LDecList LDecl
  | LDecl
  ;

LDecl:
  Type IdList SEMICOLON
  ;

IdList:
  IdList COMMA ID
  {
      handleLidInstall($3->varname, &currentTypeData);
  }
  | ID
  {
      handleLidInstall($1->varname, &currentTypeData);
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * MAIN BLOCK
 * ════════════════════════════════════════════════════════════════ */

MainBlock:
  INT MAIN
  {
      current_function_name = "MAIN";
      current_class_entry   = NULL;   /* main is never a class method */
  }
  LPAREN RPAREN LBRACE LdeclBlock Body RBRACE
  {
      handleMainPrint($8);
      $$ = $8;

      struct Gsymbol *main_func = malloc(sizeof(struct Gsymbol));
      main_func->name = "MAIN";

      codeGen($$, interim_file, main_func);

      current_function_name = NULL;
      current_class_entry   = NULL;
      resetLocalSymbolTable();
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * STATEMENT LISTS AND STATEMENTS
 * ════════════════════════════════════════════════════════════════ */

Body:
  kBEGIN Slist kEND { $$ = $2; }
  | kBEGIN kEND     { $$ = NULL; }
  ;

Slist:
  Slist Stmt SEMICOLON { $$ = makeConnectorNode($1, $2); }
  | Stmt SEMICOLON     { $$ = $1; }
  ;

Stmt:
  InputStmt    { $$ = $1; }
  | OutputStmt { $$ = $1; }
  | AssgStmt   { $$ = $1; }
  | IfStmt     { $$ = $1; }
  | WhileStmt  { $$ = $1; }
  | BreakStmt  { $$ = $1; }
  | ContinueStmt { $$ = $1; }
  | RETURN E   { $$ = makeReturnNode($2, current_function_name); }
  | RETURN     { $$ = makeReturnNode(NULL, current_function_name); }
  | FreeStmt   { $$ = $1; }
  | InitStmt   { $$ = $1; }
  | DeleteStmt { $$ = $1; }
  ;

/* ════════════════════════════════════════════════════════════════
 * INPUT / OUTPUT
 * ════════════════════════════════════════════════════════════════ */

InputStmt:
  READ LPAREN ID RPAREN
  {
      $$ = makeReadNode(makeVarNode($3->varname));
  }
  | READ LPAREN ID LSQBR E RSQBR RPAREN
  {
      $$ = makeReadNode(makeArrayNode($3, $5));
  }
  | READ LPAREN MUL ID RPAREN
  {
      tnode *ptr = makeVarNode($4->varname);
      $$ = makeReadNode(makeDerefNode(ptr));
  }
  ;

OutputStmt:
  WRITE LPAREN E RPAREN { $$ = makeWriteNode($3); }
  ;

/* ════════════════════════════════════════════════════════════════
 * MEMORY MANAGEMENT
 * ════════════════════════════════════════════════════════════════ */

FreeStmt:
  FREE_KW LPAREN LValue RPAREN { $$ = makeFreeNode($3); }
  ;

DeleteStmt:
  DELETE_KW LPAREN LValue RPAREN { $$ = makeFreeNode($3); }
  ;

InitStmt:
  INITIALIZE LPAREN RPAREN { $$ = makeInitializeNode(); }
  ;

/* ════════════════════════════════════════════════════════════════
 * ASSIGNMENT STATEMENTS
 *
 * Stage 7 addition:
 *   LValue ASSIGN NEW_KW ID LPAREN RPAREN
 *     Allocates a new instance of a class.
 *     makeNewNode() checks that the class exists and produces a
 *     NODE_NEW with type=TYPE_CLASS / typeEntry=cls->type.
 *     makeAssignNode() then verifies the l-value is of the same class.
 * ════════════════════════════════════════════════════════════════ */

AssgStmt:
  LValue ASSIGN E
  {
      $$ = makeAssignNode($1, $3);
  }
  | MUL ID ASSIGN E %prec UNARY
  {
      tnode *deref = makeDerefNode(makeVarNode($2->varname));
      $$ = makeAssignNode(deref, $4);
  }
  | LValue ASSIGN ALLOC LPAREN RPAREN
  {
      $$ = makeAssignNode($1, makeAllocNode($1));
  }
  | LValue ASSIGN NEW_KW ID LPAREN RPAREN
  {
      /*
       * new ClassName()
       * makeNewNode() semantic-checks that ID is a known class.
       * makeAssignNode() verifies the class type matches the l-value.
       */
      $$ = makeAssignNode($1, makeNewNode($4->varname));
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * L-VALUES  (assignable expressions)
 *
 * Stage 7 addition:
 *   SELF_KW DOT ID  — field assignment via self (inside class methods).
 *   makeFieldNode() enforces privacy: the field access is only valid
 *   when current_class_entry matches the class that owns the field.
 * ════════════════════════════════════════════════════════════════ */

LValue:
  ID
  {
      $$ = makeVarNode($1->varname);
  }
  | ID LSQBR E RSQBR
  {
      $$ = makeArrayNode($1, $3);
  }
  | FieldAccess
  ;

/* ════════════════════════════════════════════════════════════════
 * FIELD ACCESS  (DOT notation)
 *
 * Rules:
 *   ID DOT ID         — struct field access (no privacy restriction)
 *                       OR class field access (privacy enforced in
 *                       makeFieldNode via current_class_entry).
 *   FieldAccess DOT ID — chained field access.
 *   SELF_KW DOT ID    — field access via self keyword.
 *                       makeSelfNode() errors if not in a class method.
 *                       makeFieldNode() then checks the field exists and
 *                       the privacy rule (same class — always satisfied
 *                       when base is self because makeSelfNode already
 *                       checked current_class_entry).
 *
 * NOTE: "SELF_KW DOT ID LPAREN …" method calls are handled in the E
 * rules below (yacc defaults to shift on LPAREN, selecting the method-
 * call rule over this field-access rule — no explicit %prec needed).
 * ════════════════════════════════════════════════════════════════ */

FieldAccess:
  ID DOT ID
  {
      tnode *base = makeVarNode($1->varname);
      $$ = makeFieldNode(base, $3->varname);
  }
  | FieldAccess DOT ID
  {
      $$ = makeFieldNode($1, $3->varname);
  }
  | SELF_KW DOT ID
  {
      /*
       * makeSelfNode()  — semantic check: must be inside a class method.
       * makeFieldNode() — semantic check: field exists; privacy satisfied
       *                   because self's typeEntry == current class.
       */
      $$ = makeFieldNode(makeSelfNode(), $3->varname);
  }
  ;

/* ════════════════════════════════════════════════════════════════
 * IF / WHILE STATEMENTS
 * ════════════════════════════════════════════════════════════════ */

IfStmt:
  IF LPAREN E RPAREN THEN Slist ELSE Slist ENDIF
  {
      $$ = makeIfElseNode($3, $6, $8);
  }
  | IF LPAREN E RPAREN THEN Slist ENDIF
  {
      $$ = makeIfNode($3, $6);
  }
  ;

WhileStmt:
  WHILE LPAREN E RPAREN DO Slist ENDWHILE { $$ = makeWhileNode($3, $6); }
  ;

BreakStmt:
  BREAK { $$ = makeBreakNode(); }
  ;

ContinueStmt:
  CONTINUE { $$ = makeContinueNode(); }
  ;

/* ════════════════════════════════════════════════════════════════
 * EXPRESSIONS
 *
 * Stage 7 additions (all shift/reduce conflicts with existing rules
 * are correctly resolved by yacc defaulting to shift on LPAREN or DOT):
 *
 *   SELF_KW
 *     → makeSelfNode(): type = TYPE_CLASS, typeEntry = current class.
 *       Errors if used outside a class method.
 *
 *   SELF_KW DOT ID LPAREN ArgList RPAREN
 *   SELF_KW DOT ID LPAREN RPAREN
 *     → makeMethodCallNode(selfNode, methodName, args)
 *       Checks method is declared in the current class.
 *       Checks argument types match.
 *       (Conflict with "SELF_KW DOT ID" in FieldAccess is resolved
 *        by shifting LPAREN — the correct behaviour.)
 *
 *   ID DOT ID LPAREN ArgList RPAREN
 *   ID DOT ID LPAREN RPAREN
 *     → makeMethodCallNode(varNode, methodName, args)
 *       Checks obj has a class type, method exists, args match.
 *       (Conflict with "ID DOT ID" in FieldAccess resolved by shifting.)
 * ════════════════════════════════════════════════════════════════ */

E:
  E PLUS E   { $$ = makeArithNode(NODE_PLUS,  $1, $3); }
  | E MINUS E { $$ = makeArithNode(NODE_MINUS, $1, $3); }
  | E MUL E   { $$ = makeArithNode(NODE_MUL,   $1, $3); }
  | E DIV E   { $$ = makeArithNode(NODE_DIV,   $1, $3); }
  | E LT E    { $$ = makeBoolNode(NODE_LT, $1, $3); }
  | E GT E    { $$ = makeBoolNode(NODE_GT, $1, $3); }
  | E EQ E    { $$ = makeBoolNode(NODE_EQ, $1, $3); }
  | E LE E    { $$ = makeBoolNode(NODE_LE, $1, $3); }
  | E GE E    { $$ = makeBoolNode(NODE_GE, $1, $3); }
  | E NE E    { $$ = makeBoolNode(NODE_NE, $1, $3); }
  | E AND E   { $$ = makeBoolNode(NODE_AND, $1, $3); }
  | E OR E    { $$ = makeBoolNode(NODE_OR,  $1, $3); }
  | NOT E     { $$ = makeNotNode($2); }
  | NUM       { $$ = $1; }
  | STRING    { $$ = $1; }
  | NULLVAL   { $$ = makeNullNode(); }

  /* ── Ordinary variable / call ─────────────────────────────── */
  | ID        { $$ = makeVarNode($1->varname); }
  | ID LPAREN ArgList RPAREN { $$ = makeFuncallNode($1->varname, $3); }
  | ID LPAREN RPAREN         { $$ = makeFuncallNode($1->varname, NULL); }

  /* ── Pointer / deref ──────────────────────────────────────── */
  | MUL E %prec UNARY        { $$ = makeDerefNode($2); }
  | ADDRESS_OF ID %prec UNARY
    {
        $$ = makePointerNode(makeVarNode($2->varname));
    }

  /* ── Grouping / array ─────────────────────────────────────── */
  | LPAREN E RPAREN          { $$ = $2; }
  | ID LSQBR E RSQBR         { $$ = makeArrayNode($1, $3); }

  /* ── Struct / class field access (via FieldAccess) ───────── */
  | FieldAccess

  /* ── Stage 7: self keyword ───────────────────────────────── */
  | SELF_KW
    {
        $$ = makeSelfNode();
    }

  /* ── Stage 7: method call via self  (self.method(args)) ──── */
  | SELF_KW DOT ID LPAREN ArgList RPAREN
    {
        /*
         * Shift/reduce note: when the parser has just seen
         * "SELF_KW DOT ID" and the lookahead is LPAREN, it shifts
         * (prefers this longer rule over reducing to FieldAccess).
         * This is the correct behaviour.
         */
        $$ = makeMethodCallNode(makeSelfNode(), $3->varname, $5);
    }
  | SELF_KW DOT ID LPAREN RPAREN
    {
        $$ = makeMethodCallNode(makeSelfNode(), $3->varname, NULL);
    }

  /* ── Stage 7: method call via object  (obj.method(args)) ─── */
  | ID DOT ID LPAREN ArgList RPAREN
    {
        /*
         * Shift/reduce note: when the parser has seen "ID DOT ID"
         * and the lookahead is LPAREN, it shifts into this rule
         * instead of reducing "ID DOT ID" to FieldAccess.
         */
        $$ = makeMethodCallNode(makeVarNode($1->varname),
                                $3->varname, $5);
    }
  | ID DOT ID LPAREN RPAREN
    {
        $$ = makeMethodCallNode(makeVarNode($1->varname),
                                $3->varname, NULL);
    }
  ;

ArgList:
  ArgList COMMA E { $$ = makeConnectorNode($1, $3); }
  | E             { $$ = $1; }
  ;

%%

/* ════════════════════════════════════════════════════════════════
 * Error handler
 * ════════════════════════════════════════════════════════════════ */

void yyerror(char *s)
{
    fprintf(stderr, "Error at line %d: %s\n", lineNumber, s);
}

/* ════════════════════════════════════════════════════════════════
 * main
 * ════════════════════════════════════════════════════════════════ */

int main(int argc, char **argv)
{
    if (argc < 3)
    {
        fprintf(stderr, "Usage: %s <input_file> <output_file>\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (fp) yyin = fp;
    else
    {
        fprintf(stderr, "Error: Cannot open input file '%s'\n", argv[1]);
        return 1;
    }

    FILE *target_file = fopen(argv[2], "w");
    if (!target_file)
    {
        fprintf(stderr, "Error: Cannot open output file '%s'\n", argv[2]);
        return 1;
    }

    interim_file = fopen("interim_file.xsm", "w");
    if (!interim_file)
    {
        fprintf(stderr, "Error: Cannot open interim file\n");
        return 1;
    }

    /* ── Initialise all tables ── */
    initTypeTable();
    initClassTable();       /* Stage 7: must come after initTypeTable */
    initReg();
    fileinit(interim_file);

    current_function_name = NULL;
    current_class_entry   = NULL;

    yyparse();
    emitExit(interim_file);

    fclose(interim_file);

    interim_file = fopen("interim_file.xsm", "r");
    rewind(interim_file);
    buildLabelTable(interim_file);
    translateLabels(interim_file, target_file);

    fclose(interim_file);
    fclose(target_file);

    return 0;
}

#ifndef CLASSTABLE_H
#define CLASSTABLE_H

#include "constants.h"
#include "typetable.h"
#include "memory.h"     /* for Paramstruct, Gsymbol */
#include <stdio.h>

/* ── Forward declaration ──────────────────────────────────────── */
typedef struct ClassTableEntry ClassTableEntry;

/* ─────────────────────────────────────────────────────────────────
 * MethodEntry
 *   Represents one method *declared* inside a class body.
 *   addMethod() simultaneously installs the method as a regular
 *   function in the Global Symbol Table (via InstallFunction) so
 *   that the existing Fdef code-generation path works unchanged.
 * ───────────────────────────────────────────────────────────────── */
typedef struct MethodEntry
{
    char            *name;          /* method name                  */
    enum varType     retType;       /* return varType               */
    TypeTableEntry  *retTypeEntry;  /* non-NULL for USERDEF/CLASS   */
    Paramstruct     *params;        /* parameter list (may be NULL) */
    int              flabel;        /* mirrors Gsymbol->flabel      */

    struct MethodEntry *next;
} MethodEntry;

/* ─────────────────────────────────────────────────────────────────
 * ClassTableEntry
 *   One row per class definition encountered in the source.
 *
 *   `type` points to the TypeTableEntry created for this class.
 *   Class fields are stored in type->fields using the same
 *   addField() / lookupField() machinery as ordinary structs.
 * ───────────────────────────────────────────────────────────────── */
struct ClassTableEntry
{
    char            *name;      /* class name                       */
    int              classId;   /* sequential id, starting at 1     */
    TypeTableEntry  *type;      /* associated TypeTableEntry        */
    MethodEntry     *methods;   /* linked list of method entries    */

    struct ClassTableEntry *next;
};

/* ── Global head of the class table ─────────────────────────── */
extern ClassTableEntry *classTableHead;

/* ── Lifecycle ─────────────────────────────────────────────────  */
void initClassTable(void);

/* ── Lookup ────────────────────────────────────────────────────  */
ClassTableEntry *lookupClass(const char *name);
MethodEntry     *lookupMethod(ClassTableEntry *cls, const char *methodName);

/*
 * findClassForMethod(methodName)
 *   Scans the entire class table and returns the ClassTableEntry
 *   whose method list contains a MethodEntry with the given name.
 *   Returns NULL if the method does not belong to any class.
 *   Used by the Fdef rule to determine whether a function being
 *   defined is a class method, and to set current_class_entry.
 */
ClassTableEntry *findClassForMethod(const char *methodName);

/* ── Install ───────────────────────────────────────────────────  */

/*
 * installClass(name)
 *   Creates a new ClassTableEntry and a matching TypeTableEntry
 *   (via installType) so that the class name is usable as a type.
 *   Exits on duplicate class names.
 */
ClassTableEntry *installClass(const char *name);

/*
 * addMethod(cls, methodName, retType, retTypeEntry, params)
 *   Adds a method declaration to the class AND calls InstallFunction
 *   to register it in the GST.  Exits on duplicate method names.
 */
MethodEntry *addMethod(ClassTableEntry  *cls,
                       const char       *methodName,
                       enum varType      retType,
                       TypeTableEntry   *retTypeEntry,
                       Paramstruct      *params);

/* ── Debug ─────────────────────────────────────────────────────  */
void printClassTable(void);

#endif /* CLASSTABLE_H */

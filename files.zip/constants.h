#ifndef CONSTANTS_H
#define CONSTANTS_H

/* ─── Memory layout (XSM) ─────────────────────────────────────── */
#define STACK_START              4096
#define MAX_FIELDS_IN_USER_TYPE  8

/* ─────────────────────────────────────────────────────────────────
 * Variable / expression type tags  (enum varType)
 *
 * These values fill two distinct roles:
 *  (a) tnode->type, Gsymbol->type, Lsymbol->type — the "kind" of a
 *      variable or expression.
 *  (b) TypeTableEntry->typeId for the built-in rows installed by
 *      initTypeTable().  User-defined struct rows get
 *      typeId = TYPE_USERDEF+1, +2, …
 *
 * The test  (t->typeId <= TYPE_USERDEF)  is therefore true iff the
 * TypeTableEntry represents a primitive / built-in type.
 * ───────────────────────────────────────────────────────────────── */
enum varType
{
    TYPE_NULL    = 0,   /* void / untyped                           */
    TYPE_INT     = 1,   /* integer                                  */
    TYPE_STRING  = 2,   /* string                                   */
    TYPE_BOOL    = 3,   /* boolean (relational / logical ops)       */
    TYPE_POINTER = 4,   /* pointer  (ptrLevel > 0)                  */
    TYPE_USERDEF = 5,   /* user-defined struct; typeIds start at 6  */
    TYPE_CLASS   = 6    /* class-typed variable / expression        */
};

/* ─────────────────────────────────────────────────────────────────
 * AST node kinds  (enum nodeType)
 * ───────────────────────────────────────────────────────────────── */
enum nodeType
{
    /* ── Literals ─────────────────────────────────────────────── */
    NODE_NUM    = 0,
    NODE_STRING,
    NODE_NULL,

    /* ── Variable / l-value nodes ────────────────────────────── */
    NODE_ID,
    NODE_ARRAY_ELEMENT,
    NODE_FIELD,          /* struct / class field via DOT             */

    /* ── Pointer nodes ────────────────────────────────────────── */
    NODE_POINTER,        /* address-of:  &x                          */
    NODE_DEREF,          /* dereference: *x                          */

    /* ── Function / method call nodes ────────────────────────── */
    NODE_FUNCALL,        /* ordinary function call                   */
    NODE_METHOD_CALL,    /* obj.method(args)  — Stage 7              */
    NODE_RET,            /* return statement                         */

    /* ── Arithmetic ───────────────────────────────────────────── */
    NODE_PLUS,
    NODE_MINUS,
    NODE_MUL,
    NODE_DIV,

    /* ── Assignment ───────────────────────────────────────────── */
    NODE_ASSIGN,
    NODE_ARRAY_ASSIGN,

    /* ── I/O ──────────────────────────────────────────────────── */
    NODE_READ,
    NODE_WRITE,

    /* ── Control flow ─────────────────────────────────────────── */
    NODE_CONNECTOR,
    NODE_WHILE,
    NODE_DOWHILE,
    NODE_REPEAT,
    NODE_IF,
    NODE_IFELSE,
    NODE_BREAK,
    NODE_CONTINUE,

    /* ── Relational / logical ─────────────────────────────────── */
    NODE_LT,
    NODE_LE,
    NODE_GT,
    NODE_GE,
    NODE_EQ,
    NODE_NE,
    NODE_AND,
    NODE_OR,
    NODE_NOT,

    /* ── Memory management (heap) ─────────────────────────────── */
    NODE_ALLOC,          /* alloc()      — heap alloc for structs    */
    NODE_FREE,           /* free()       — heap free  for structs    */
    NODE_INITIALIZE,     /* initialize() — heap initialisation       */

    /* ── Class-specific  —  Stage 7 ──────────────────────────── */
    NODE_NEW,            /* new ClassName()  — class instantiation   */
    NODE_DELETE,         /* delete(obj)      — class deallocation    */
    NODE_SELF            /* self keyword     — current object ref    */
};

#endif /* CONSTANTS_H */
